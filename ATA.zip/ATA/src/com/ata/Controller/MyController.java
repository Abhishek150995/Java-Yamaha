package com.ata.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ata.bean.CredentialsBean;
import com.ata.bean.DriverBean;
import com.ata.bean.ProfileBean;
import com.ata.bean.ReservationBean;
import com.ata.bean.RouteBean;
import com.ata.bean.VehicleBean;
import com.ata.dao.CredentialsDAO;
import com.ata.dao.DriverDAO;
import com.ata.dao.ProfileBeanDAO;
import com.ata.dao.RouteDAO;
import com.ata.dao.VehicleDAO;
import com.ata.service.Administrator;
import com.ata.service.Customer;
import com.ata.util.User;

@Transactional

@Controller
@ComponentScan(basePackages = "com")
public class MyController {
	@Autowired
	Administrator ad;
	@Autowired
	Customer cs;
	@Autowired
	User usr;
	@Autowired
	CredentialsDAO cd;
	@Autowired
	VehicleDAO vd;
	@Autowired
	SessionFactory sf;
	@Autowired
	ProfileBeanDAO pd;
	@Autowired
	DriverDAO dd;
	@Autowired
	RouteDAO rd;
	
//===============================================================================================================================================
	@RequestMapping("login")
	public String newLoginPage(Model m) {

		m.addAttribute("credentialsBean", new CredentialsBean());
		return "login";
	}

	@RequestMapping("loginDetails")
	public String loginUser(@Valid @ModelAttribute("credentialsBean") CredentialsBean credentialsBean, Model m,HttpSession session) {

		String s = usr.login(credentialsBean);
		if (s.equals("Login Success")) {
			CredentialsBean c = cd.findByID(credentialsBean.getUserID());
			session.setAttribute("customer", c);
			String userType = c.getUserType();
			if (userType.equals("A")) {
				m.addAttribute("profileBean", new ProfileBean());
				
				return "reg";
			} else {
				return "customerDashboard";
			}
		} else if (s.equals("Login Failed")) {
			m.addAttribute("loginmsg", s);
			return "login";
		} else
			return "login";

	}
//===============================================================================================================================================
	@RequestMapping("newUser")
	public String newUserPage(Model m) {

		m.addAttribute("profileBean", new ProfileBean());
		return "reg";
	}

	@RequestMapping("addProfile")
	public String createProfile(@RequestParam("dateOfBirth") String d, @ModelAttribute("profileBean") ProfileBean profileBean, BindingResult br,
			Model m) throws ParseException {

		Date date1=new SimpleDateFormat("dd-MM-yyyy").parse(d);
		System.out.println(d);
		System.out.println(date1);
		
		
		/*if (br.hasErrors()) {
			System.out.println("error");
			m.addAttribute("profileBean", profileBean);
			return "reg";
		} else {*/
			System.out.println("hi");
			String result = usr.register(profileBean);
			System.out.println(result);

			m.addAttribute("success", result);
			return "redirect:newUser";
		}

	/*}*/
	@ModelAttribute("getAllUsers")
	public ArrayList<ProfileBean> getAllUsers(Model m) {
		ArrayList<ProfileBean> li = pd.findAll();

		return li;
	}
	@RequestMapping("editProfile")
	public String editUser(@RequestParam("editbutton") String editbutton, Model m) {

		Session ses = sf.getCurrentSession();

		ProfileBean vb = ses.get(ProfileBean.class, Long.parseLong(editbutton));
		System.out.println(vb);
		m.addAttribute("profileBeanEdit", vb);

		m.addAttribute("profileBean", new ProfileBean());

		return "reg";

	}

	@RequestMapping("updateProfile")
	public String updateUser( @ModelAttribute("profileBean") ProfileBean profileBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("profileBean", profileBean);
			return "reg";
		} else {

			boolean result = pd.updateProfileBean(profileBean);
			System.out.println("hiiiiiiiiiiiiiii");
			System.out.println(result);

			return "redirect:newUser";
		}

	}

	@RequestMapping("deleteProfile")
	public String deleteUser(@RequestParam("deletebutton") String deletebutton, Model m) {

		System.out.println(deletebutton);

		int result = pd.deleteProfileBean(deletebutton);

		if (result > 0) {

			return "redirect:newUser";
		} else {

			return "redirect:newUser";
		}

	}

	//===============================================================================================================================================
	@RequestMapping("newDriver")
	public String newDriverPage(Model m) {

		m.addAttribute("driverBean", new DriverBean());
		return "driverReg";
	}

	@RequestMapping("addDriver")
	public String addDriver(@Valid @ModelAttribute("driverBean") DriverBean driverBean, BindingResult br, Model m) {

		if (br.hasErrors()) {
			m.addAttribute("driverBean", driverBean);
			return "driverReg";
		} else {
			System.out.println("hello");
			String result = ad.addDriver(driverBean);

			m.addAttribute("success", result);
			return "redirect:newDriver";
		}

	}
	@RequestMapping("editDriver")
	public String editDriver(@RequestParam("editbutton") String editbutton, Model m) {

		Session ses = sf.getCurrentSession();

		DriverBean db = ses.get(DriverBean.class, Long.parseLong(editbutton));
		System.out.println(db);
		m.addAttribute("driverBeanEdit", db);

		m.addAttribute("driverBean", new DriverBean());

		return "driverReg";

	}

	@RequestMapping("deleteDriver")
	public String deleteDriver(@RequestParam("deletebutton") String deletebutton, Model m) {

		System.out.println(deletebutton);

		int result = ad.deleteDriver(deletebutton);

		if (result > 0) {

			return "redirect:newDriver";
		} else {

			return "redirect:newDriver";
		}

	}

	@ModelAttribute("getAllDrivers")
	public List<DriverBean> getAllDrivers(Model m) {
		ArrayList<DriverBean> li = dd.findAll();

		return li;
	}
	
	@RequestMapping("updateDriver")
	public String updateUser( @ModelAttribute("driverBean") DriverBean driverBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("driverBean", driverBean);
			return "driverReg";
		} else {

			boolean result = dd.updateDriver(driverBean);
			System.out.println("hiiiiiiiiiiiiiii");
			System.out.println(result);

			return "redirect:newDriver";
		}

	}
	
	
	
	//===============================================================================================================================================
	@RequestMapping("newVehicle")
	public String newVehiclePage(Model m) {

		m.addAttribute("vehicleBean", new VehicleBean());
		return "vehicleReg";

	}

	@RequestMapping("addVehicle")
	public String addVehicle(@Valid @ModelAttribute("vehicleBean") VehicleBean vehicleBean, BindingResult br, Model m) {

		if (br.hasErrors()) {
			m.addAttribute("vehicleBean", vehicleBean);
			return "driverReg";
		} else {

			String result = ad.addVehicle(vehicleBean);
			System.out.println(result);
			ArrayList<VehicleBean> li = vd.findAll();

			m.addAttribute("list", li);
			return "redirect:newVehicle";
		}

	}

	@ModelAttribute("getAllVehicles")
	public List<VehicleBean> getAllVehicles(Model m) {
		ArrayList<VehicleBean> li = vd.findAll();

		return li;
	}

	@RequestMapping("editVehicle")
	public String editVehicle(@RequestParam("editbutton") String editbutton, Model m) {

		Session ses = sf.getCurrentSession();

		VehicleBean vb = ses.get(VehicleBean.class, Long.parseLong(editbutton));
		System.out.println(vb);
		m.addAttribute("vehicleBeanEdit", vb);

		m.addAttribute("vehicleBean", new VehicleBean());

		return "vehicleReg";

	}

	@RequestMapping("updateVehicle")
	public String updateVehicle(@Valid @ModelAttribute("vehicleBean") VehicleBean vehicleBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("vehicleBean", vehicleBean);
			return "vehicleReg";
		} else {

			boolean result = ad.modifyVehicle(vehicleBean);
			System.out.println(result);

			return "redirect:newVehicle";
		}

	}

	@RequestMapping("deleteVehicle")
	public String deleteVehicle(@RequestParam("deletebutton") String deletebutton, Model m) {

		System.out.println(deletebutton);

		int result = ad.deleteVehicle(deletebutton);

		if (result > 0) {

			return "redirect:newVehicle";
		} else {

			return "redirect:newVehicle";
		}

	}
	/*@RequestMapping("viewAllVehicle")
	public String viewAllVehicle(Model m) {

		m.addAttribute("vehicleBean", new VehicleBean());
		return "CustViewPage";

	}*/
	@RequestMapping("viewVehicleBySeats")
	public String viewVehicleBySeats(Model m) {

		m.addAttribute("vehicleBean", new VehicleBean());
		return "CustViewPage";

	}

	
	
	@RequestMapping("selectedNoOfSeats")
	public String selectedNoOfSeats(@ModelAttribute("vehicleBean") VehicleBean vehicleBean, Model m) {
		int noOfSeats= vehicleBean.getSeatingCapacity();
		System.out.println(noOfSeats);
		ArrayList<VehicleBean> vb=cs.viewVehiclesBySeats(noOfSeats);
		System.out.println(vb);
		m.addAttribute("vehicleBeanBySeats", vb);
		return "CustViewPage";

	}
	@ModelAttribute("NoOfSeats")
	public List<Integer> NoOfSeats(Model m) {
		Session ses=sf.getCurrentSession();
		Query q=ses.createNativeQuery("select Distinct seatingcapacity from ata_tbl_vehicle");
		
		List<Integer> li=q.getResultList();
		
		
		return (ArrayList<Integer>) li;
		
	}
	@RequestMapping("viewVehicleByType")
	public String viewVehicleByType(Model m) {

		m.addAttribute("vehicleBean", new VehicleBean());
		return "CustViewPage";

	}
	
	
	
	@RequestMapping("selectedVehicleByType")
	public String selectedVehicleByType(@ModelAttribute("vehicleBean") VehicleBean vehicleBean, Model m) {
		String vehicleType= vehicleBean.getType();
		System.out.println(vehicleType);
		ArrayList<VehicleBean> vb=cs.viewVehiclesByType(vehicleType);
		System.out.println(vb);
		m.addAttribute("vehicleBeanByType", vb);
		return "CustViewPage";

	}
	@ModelAttribute("vehicleType")
	public List<String> vehicleType(Model m) {
		Session ses=sf.getCurrentSession();
		Query q=ses.createNativeQuery("select Distinct type from ata_tbl_vehicle");
		
		List<String> li=q.getResultList();
		
		
		return (ArrayList<String>) li;
		
	}
	
	
	
	
	
	
	
	
//===============================================================================================================================================
	@RequestMapping("newRoute")
	public String newRoutePage(Model m) {

		m.addAttribute("routeBean", new RouteBean());
		return "routeReg";

	}

	@RequestMapping("addRoute")
	public String addRoute(@Valid @ModelAttribute("routeBean") RouteBean routeBean, BindingResult br, Model m) {

		if (br.hasErrors()) {
			m.addAttribute("routeBean", routeBean);
			return "routeReg";
		} else {

			String result = ad.addRoute(routeBean);
			System.out.println(result);
			ArrayList<RouteBean> li = cs.viewAllRoutes();

			m.addAttribute("list", li);
			return "redirect:newRoute";

		}

	}
	
	@ModelAttribute("getAllRoutes")
	public List<RouteBean> getAllRoutes(Model m) {
		ArrayList<RouteBean> li = rd.findAll();

		return li;
	}

	@RequestMapping("editRoute")
	public String editRoute(@RequestParam("editbutton") String editbutton, Model m) {

		Session ses = sf.getCurrentSession();

		RouteBean rb = ses.get(RouteBean.class, Long.parseLong(editbutton));
		
		m.addAttribute("routeBeanEdit", rb);

		m.addAttribute("routeBean", new RouteBean());

		return "routeReg";

	}

	@RequestMapping("updateRoute")
	public String updateRoute(@Valid @ModelAttribute("routeBean") RouteBean routeBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("routeBean", routeBean);
			return "routeReg";
		} else {

			boolean result = ad.modifyRoute(routeBean);
			System.out.println(result);

			return "redirect:newRoute";
		}

	}

	@RequestMapping("deleteRoute")
	public String deleteRoute(@RequestParam("deletebutton") String deletebutton, Model m) {

		System.out.println(deletebutton);

		int result = ad.deleteRoute(deletebutton);

		if (result > 0) {

			return "redirect:newRoute";
		} else {

			return "redirect:newRoute";
		}

	}
	
	@RequestMapping("viewAllRoutes")
	public String viewAllRoutes(Model m) {
		ArrayList<RouteBean> li = rd.findAll();
		m.addAttribute("routeList", li);
		return "customerRoutes";

	}
//===============================================================================================================================================
	@RequestMapping("createReservation")
	public String createReservation(Model m) {

		m.addAttribute("reservationBean", new ReservationBean());
		return "reservation";

	} 
	@RequestMapping("addReservation")
	public String addReservation(@ModelAttribute("reservationBean") ReservationBean reservationBean , Model m, HttpSession ses) {
		ses.getAttribute("customer");
		reservationBean.setCredentials("customer");
		cs.bookVehicle(reservationBean, );

		return "routeReg";

	}
	
	

}
