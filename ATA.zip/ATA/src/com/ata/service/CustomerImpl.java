package com.ata.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.ReservationBean;
import com.ata.bean.RouteBean;
import com.ata.bean.VehicleBean;
import com.ata.dao.RouteDAO;
import com.ata.dao.VehicleDAO;
@Service
@Transactional
public class CustomerImpl implements Customer {

	@Autowired
	VehicleDAO vd;
	@Autowired
	RouteDAO rd;
	@Override
	public ArrayList<VehicleBean> viewVehiclesByType(String vehicleType) {
		// TODO Auto-generated method stub
		return vd.findAll(vehicleType);
	}

	@Override
	public ArrayList<VehicleBean> viewVehiclesBySeats(int noOfSeats) {
		
		return vd.findAll(noOfSeats);
	}

	@Override
	public ArrayList<RouteBean> viewAllRoutes() {
		// TODO Auto-generated method stub
		return rd.findAll();
	}

	@Override
	public String bookVehicle(ReservationBean reservationbean,HttpSession ses) {
		ReservationBean rTemp= reservationbean;
		 Date date = Calendar.getInstance().getTime();  
         DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
         String bookingDate = dateFormat.format(date);  
		rTemp.setBookingDate(bookingDate);
		rTemp.setBookingStatus("Pending with Admin");
	
		ses.getAttribute("customer");
		
		
		return null;
	}

	@Override
	public boolean cancelBooking(String userID, String reservationID) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ReservationBean viewBookingDetails(String reservationID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReservationBean printBookingDetails(String reservationID) {
		// TODO Auto-generated method stub
		return null;
	}

}
