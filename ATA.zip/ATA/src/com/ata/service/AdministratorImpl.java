package com.ata.service;

import java.util.ArrayList;
import java.util.Date;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.DriverBean;
import com.ata.bean.ReservationBean;
import com.ata.bean.RouteBean;
import com.ata.bean.VehicleBean;
import com.ata.dao.DriverDAO;
import com.ata.dao.RouteDAO;
import com.ata.dao.VehicleDAO;

@Service
@Transactional
public class AdministratorImpl implements Administrator {
@Autowired
	VehicleDAO vd;
@Autowired
	DriverDAO dd;
@Autowired
RouteDAO rd;
	@Override
	public String addVehicle(VehicleBean vehicleBean) {
		
		return vd.createVehicle(vehicleBean);
	}

	@Override
	public int deleteVehicle(String deleteVehicle) {
		System.out.println("admin");
		return vd.deleteVehicle(deleteVehicle);
	}

	@Override
	public VehicleBean viewVehicle(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean modifyVehicle(VehicleBean VehicleBean) {
		
		return vd.updateVehicle(VehicleBean);
	}

	@Override
	public String addDriver(DriverBean driverbean) {
		return dd.createDriver(driverbean);
	}

	@Override
	public int deleteDriver(String deleteDriver) {
		System.out.println("admin");
		return dd.deleteDriver(deleteDriver);
	}

	@Override
	public boolean modifyDriver(DriverBean driverbean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean allotDriver(String reservationID, String driverID) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String addRoute(RouteBean routeBean) {
		
		return rd.createRoute(routeBean);
	}

	@Override
	public int deleteRoute(String deleteRoute) {
		
		return rd.deleteRoute(deleteRoute);
	}

	@Override
	public boolean modifyRoute(RouteBean routeBean) {
		
		return rd.updateRoute(routeBean);
	}

	@Override
	public RouteBean viewRoute(String id) {
	
		return null;
	}

	@Override
	public ArrayList<ReservationBean> viewBookingDetails(Date journeyDate, String source, String destination) {
		
		return null;
	}

}
