package com.ata.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ATA_TBL_VEHICLE")
public class VehicleBean {

	@Id
	@SequenceGenerator(name="seq",sequenceName="ata_seq_vehicleId")        
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@Column(length = 6)
	private long vehicleID;
	@NotEmpty
	@Column(length = 20)
	private String name;
	@NotEmpty
	@Column(length = 8)
	private String type;
	@NotEmpty
	@Column(length = 12)
	private String registrationNumber;
	@NotNull
	@Column(length = 3)
	private int seatingCapacity;
	@NotNull
	@Column(length = 3)
	private double farePerKM;
	public VehicleBean() {}
	public VehicleBean(long vehicleID, String name, String type, String registrationNumber, int seatingCapacity,
			double farePerKM) {
		super();
		this.vehicleID = vehicleID;
		this.name = name;
		this.type = type;
		this.registrationNumber = registrationNumber;
		this.seatingCapacity = seatingCapacity;
		this.farePerKM = farePerKM;
	}

	public long getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(long vehicleID) {
		this.vehicleID = vehicleID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public int getSeatingCapacity() {
		return seatingCapacity;
	}

	public void setSeatingCapacity(int seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}

	public double getFarePerKM() {
		return farePerKM;
	}

	public void setFarePerKM(double farePerKM) {
		this.farePerKM = farePerKM;
	}

}
