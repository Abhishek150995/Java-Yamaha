package com.ata.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ATA_TBL_ROUTE")
public class RouteBean {

	@Id
	@SequenceGenerator(name="seq",sequenceName="ata_seq_routeId")        
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@Column(length = 8)
	private long routeID;
	@NotEmpty
	@Column(length = 20)
	private String source;
	@NotEmpty
	@Column(length = 20)
	private String destination;
	
	@NotNull
	@Column(length = 4)
	private int distance;
	@NotNull
	@Column(length = 3)
	private int travelDuration;
	public RouteBean() {}
	public RouteBean(long routeID, String source, String destination, int distance, int travelDuration) {
		super();
		this.routeID = routeID;
		this.source = source;
		this.destination = destination;
		this.distance = distance;
		this.travelDuration = travelDuration;
	}

	public long getRouteID() {
		return routeID;
	}

	public void setRouteID(long routeID) {
		this.routeID = routeID;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public int getTravelDuration() {
		return travelDuration;
	}

	public void setTravelDuration(int travelDuration) {
		this.travelDuration = travelDuration;
	}

}
