package com.ata.util;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.CredentialsBean;
import com.ata.dao.CredentialsDAO;
@Component
@Transactional
public class AuthenticationImpl implements Authentication{
	@Autowired
	CredentialsDAO cd;
	
	
	@Override
	public boolean authenticate(CredentialsBean credentialsBean) {
	CredentialsBean c=cd.findByID(credentialsBean.getUserID());
	
	if(c.getPassword().equals(credentialsBean.getPassword()))
	{
		changeLoginStatus(c, 1);
		
		
		
		return true;
	}else 
		return false;
	}

	@Override
	public String authorize(String userID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changeLoginStatus(CredentialsBean credentialsBean, int loginStatus) {
		credentialsBean.setLoginStatus(loginStatus);
		return true;
	}

}
