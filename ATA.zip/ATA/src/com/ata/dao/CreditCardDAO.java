package com.ata.dao;

import java.util.ArrayList;

import com.ata.bean.CreditCardCredentialsBean;

public interface CreditCardDAO {
	String createCreditCard(CreditCardCredentialsBean creditCardBean);
	int deleteCreditCard(String deleteCC) ;
	boolean updateCreditCard(CreditCardCredentialsBean creditCardBean) ;
	CreditCardCredentialsBean findByID(String id) ;
	ArrayList<CreditCardCredentialsBean> findAll();
	boolean ckeckbalance(float payment);
	void updateCreditCardBalance(String creditCardNumber, Double totalFare);

}
