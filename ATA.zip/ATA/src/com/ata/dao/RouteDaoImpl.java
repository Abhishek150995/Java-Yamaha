package com.ata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ata.bean.RouteBean;
import com.ata.bean.VehicleBean;

@Repository
public class RouteDaoImpl implements RouteDAO{
	@Autowired
	SessionFactory sf;
	@Override
	public String createRoute(RouteBean routeBean) {
		Session ses=sf.getCurrentSession();
		ses.save(routeBean);
		
		return "Route Created with ID:"+routeBean.getRouteID();
	}

	@Override
	public int deleteRoute(String deleteRoute) {
		System.out.println("impl");
		Session ses=sf.getCurrentSession();
		RouteBean rb=ses.get(RouteBean.class, Long.parseLong(deleteRoute));
		System.out.println(rb);
		ses.delete(rb);
		return 1;
	}

	@Override
	public boolean updateRoute(RouteBean routeBean) {
		Session ses=sf.getCurrentSession();
		ses.update(routeBean);
		return true;
	}

	@Override
	public RouteBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<RouteBean> findAll() {
		Session ses=sf.getCurrentSession();
		Query q=ses.createQuery("from RouteBean r");
		List<RouteBean> li=q.getResultList();
		return (ArrayList<RouteBean>) li;
	}

	@Override
	public int generateRouteId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
