package com.ata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.DriverBean;
import com.ata.bean.VehicleBean;

@Transactional
@Repository
@ComponentScan(basePackages="com")
public class DriverDAOImpl implements DriverDAO {
	@Autowired
	SessionFactory sf;
	@Override
	public String createDriver(DriverBean driverbean) {
		System.out.println("h");
		Session ses=sf.getCurrentSession();
		ses.save(driverbean);
		return "Driver Created with userid:"+driverbean.getDriverID();
	}

	

	@Override
	public boolean updateDriver(DriverBean driverbean) {
		Session ses=sf.getCurrentSession();
		ses.update(driverbean);
		return true;
	}

	@Override
	public DriverBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<DriverBean> findAll() {
		Session ses=sf.getCurrentSession();
		Query q=ses.createQuery("from DriverBean v");
		List<DriverBean> li=q.getResultList();
		return (ArrayList<DriverBean>) li;
	}

	@Override
	public int generateDriverId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean setdriverstatus(DriverBean driverBean, String driverid) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public int deleteDriver(String deleteDriver) {
		System.out.println("impl");
		Session ses=sf.getCurrentSession();
		DriverBean db=ses.get(DriverBean.class, Long.parseLong(deleteDriver));
		System.out.println(db);
		ses.delete(db);
		return 1;
	}

}
