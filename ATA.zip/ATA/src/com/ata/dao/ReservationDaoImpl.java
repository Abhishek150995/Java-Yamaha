package com.ata.dao;

import org.springframework.stereotype.Repository;

import com.ata.bean.ReservationBean;

@Repository
public class ReservationDaoImpl implements ReservationDAO{

	@Override
	public String createReservation(ReservationBean reservationbean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteReservation(String deleteReservation) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateReservation(ReservationBean reservationbean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ReservationBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String generateReservationId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findRouteID(String s1, String s2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findVehicleID(String s3, int s4) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findUserId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findDriverId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int findtotalkm(String routeID) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double findfareperkm(String vehicleId) {
		// TODO Auto-generated method stub
		return 0;
	}

}
