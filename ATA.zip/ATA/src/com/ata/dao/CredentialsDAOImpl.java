package com.ata.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.CredentialsBean;
@Repository
@Transactional
public class CredentialsDAOImpl implements CredentialsDAO {
	@Autowired
	SessionFactory sf;
	@Override
	public String createCredentials(CredentialsBean credentialsBean) {
		// TODO Auto-generated method stub
		return null;
	}

	

	@Override
	public boolean updateCredentials(CredentialsBean credentialsBean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public CredentialsBean findByID(long id) {
		Session ses=sf.getCurrentSession();
		CredentialsBean cb=ses.get(CredentialsBean.class, id);
		if(cb!=null)
			return cb;
		else
		return null;
	}

	@Override
	public ArrayList<CredentialsBean> findAll() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public int deleteCredentials(String deleteCredentials) {
		// TODO Auto-generated method stub
		return 0;
	}

}
