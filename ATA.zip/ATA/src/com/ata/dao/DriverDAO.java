package com.ata.dao;

import java.util.ArrayList;

import com.ata.bean.DriverBean;

public interface DriverDAO {
	String createDriver(DriverBean driverbean);
	int deleteDriver(String deleteDriver) ;
	boolean updateDriver(DriverBean driverbean) ;
	DriverBean findByID(String id) ;
	ArrayList<DriverBean> findAll();
	int generateDriverId();
	boolean setdriverstatus(DriverBean driverBean, String driverid);
}
