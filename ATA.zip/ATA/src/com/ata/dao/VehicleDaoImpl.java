package com.ata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.VehicleBean;
@Repository
@Transactional
public class VehicleDaoImpl implements VehicleDAO{
	@Autowired
	SessionFactory sf;
	@Override
	public String createVehicle(VehicleBean vehicleBean) {
		Session ses=sf.getCurrentSession();
		ses.save(vehicleBean);
		
		return "Vehicle Created with name:"+vehicleBean.getName();
		
	}

	@Override
	public int deleteVehicle(String deleteVehicle) {
		System.out.println("impl");
		Session ses=sf.getCurrentSession();
		VehicleBean vb=ses.get(VehicleBean.class, Long.parseLong(deleteVehicle));
		System.out.println(vb);
		ses.delete(vb);
		return 1;
	}

	@Override
	public boolean updateVehicle(VehicleBean VehicleBean) {
		Session ses=sf.getCurrentSession();
		ses.update(VehicleBean);
		return true;
	}

	@Override
	public VehicleBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<VehicleBean> findAll() {
		Session ses=sf.getCurrentSession();
		Query q=ses.createQuery("from VehicleBean v");
		List<VehicleBean> li=q.getResultList();
		return (ArrayList<VehicleBean>) li;
		
	}

	@Override
	public ArrayList<VehicleBean> findAll(int noOfSeats) {
		Session ses=sf.getCurrentSession();
		Query q=ses.createQuery("from VehicleBean v where v.seatingCapacity =:n");
		q.setParameter("n", noOfSeats);
		List<VehicleBean> li=q.getResultList();
		return (ArrayList<VehicleBean>) li;
	}

	@Override
	public ArrayList<VehicleBean> findAll(String vehicleType) {
		Session ses=sf.getCurrentSession();
		Query q=ses.createQuery("from VehicleBean v where v.type =:n");
		q.setParameter("n", vehicleType);
		List<VehicleBean> li=q.getResultList();
		return (ArrayList<VehicleBean>) li;
	}

	@Override
	public int generateVehicleId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getTotalSeats(String vehicleID) {
		// TODO Auto-generated method stub
		return 0;
	}

}
