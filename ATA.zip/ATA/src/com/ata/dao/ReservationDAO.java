package com.ata.dao;

import java.util.ArrayList;

import com.ata.bean.ReservationBean;

public interface ReservationDAO {
	String createReservation(ReservationBean reservationbean);
	int deleteReservation( String deleteReservation) ;
	boolean updateReservation(ReservationBean reservationbean) ;
	ReservationBean findByID(String id) ;
	
	String generateReservationId();
	String findRouteID(String s1, String s2);
	String findVehicleID(String s3,int s4);
    String findUserId();
    String findDriverId();
    int findtotalkm(String routeID);
    double findfareperkm(String vehicleId);
    // String UserIdfromReservationID(String reservationID);

}
