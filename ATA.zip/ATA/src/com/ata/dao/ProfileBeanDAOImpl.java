package com.ata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.ProfileBean;
import com.ata.bean.VehicleBean;

@Repository
@Transactional
@ComponentScan(basePackages="com")
public class ProfileBeanDAOImpl implements ProfileBeanDAO {
@Autowired
	SessionFactory sf;
	@Override
	public String createProfileBean(ProfileBean pb) {
		System.out.println("dao");
		Session ses=sf.getCurrentSession();
		pb.getCredentialsBean().setLoginStatus(0);
		pb.getCredentialsBean().setUserType("C");
		ses.save(pb);
		return "Customer Created with userid:"+pb.getUserID();
		
	}

	

	@Override
	public boolean updateProfileBean(ProfileBean pb) {
		Session ses=sf.getCurrentSession();
		ses.update(pb);
		return true;
	}

	@Override
	public ProfileBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ProfileBean> findAll() {
		Session ses=sf.getCurrentSession();
		Query q=ses.createQuery("from ProfileBean p");
		List<ProfileBean> li=q.getResultList();
		return (ArrayList<ProfileBean>) li;
		
	}

	@Override
	public int generateUserId() {
		// TODO Auto-generated method stub
		return 0;
	}



	@Override
	public int deleteProfileBean(String deleteProfile) {
		Session ses=sf.getCurrentSession();
		ProfileBean pb=ses.get(ProfileBean.class, Long.parseLong(deleteProfile));
		System.out.println(pb);
		ses.delete(pb);
		return 1;
		
	}

}
