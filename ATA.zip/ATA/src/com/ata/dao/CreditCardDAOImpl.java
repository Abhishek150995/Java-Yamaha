package com.ata.dao;

import java.util.ArrayList;

import com.ata.bean.CreditCardCredentialsBean;

public class CreditCardDAOImpl implements CreditCardDAO {

	@Override
	public String createCreditCard(CreditCardCredentialsBean creditCardBean) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public boolean updateCreditCard(CreditCardCredentialsBean creditCardBean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public CreditCardCredentialsBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<CreditCardCredentialsBean> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean ckeckbalance(float payment) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void updateCreditCardBalance(String creditCardNumber, Double totalFare) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public int deleteCreditCard(String deleteCC) {
		// TODO Auto-generated method stub
		return 0;
	}

}
